const MAX_BINARY_SEARCH_ITERATIONS = 25;
const SPARKLINE_VERTICAL_PADDING = 12;
const SPARKLINE_OFFSET = 6;
const DASHBOARD_DEBUG = false;
const WORKLOAD_BUCKET_COLUMNS = 7;
const WORKLOAD_BUCKET_DAYS = 21;
const WORKLOAD_VISIBLE_ASSIGNMENTS = 2;
const WORKLOAD_ASSIGNMENT_TITLE_MAX_LENGTH = 30;
// Deterministic fallback if shared trimester detection is temporarily unavailable.
const DEFAULT_TRIMESTER_CODE = 'T3';
const NO_GRADEABLE_TRIMESTER_MESSAGE = 'No gradeable assignments in this trimester';

class AcademicDashboard {
    constructor() {
        this.canvasData = null;
        this.lastUpdate = null;
        this.briefing = null;
        this.blackbaudUserId = null;
        this.activeScheduleWeekOffset = 0;
        this.scheduleWeekDefinitions = this.getScheduleWeekDefinitions(new Date());
        this.scheduleWeekCache = {};
        this.scheduleRequestToken = 0;
        this.scheduleLoadErrorMessage = '';
        this.weeklyScheduleEntries = [];
        this.activeScheduleDayIndex = this.getInitialScheduleDayIndex(new Date());
        this.weeklyMenuByDate = new Map();
        this.maxMenuDayCount = 7;
        this.menuDisplayDayCount = this.maxMenuDayCount;
        this.selectedTarget = null;
        this.simulatorCache = new Map();
        this.simulatorRows = [];
        this.simulatorMeta = null;
        this.workloadChartEventsBound = false;
        this.toolManager = typeof window.ToolManager === 'function' ? new window.ToolManager() : null;
        this.gradeAnalyzerTool = this.toolManager?.getTool('gradeAnalyzer') || null;
        this.hasLoggedGradeAnalyzerFallback = false;
        this.currentTrimesterInfo = this.getTrimesterInfo(new Date());
        this.selectedTrimester = this.currentTrimesterInfo?.code || DEFAULT_TRIMESTER_CODE;
        this.init();
    }

    async init() {
        this.cacheElements();
        this.bindEvents();
        await this.loadCachedData();
        this.renderHeader();
        this.renderGradeTrends();
        this.renderWeeklyWorkloadChart();
        this.renderCourseHealthGrid();
        this.populateCourseSelector();
        this.updateActiveTrimesterButtons();
        this.renderScheduleWeekButtons();
        this.renderScheduleWeekRange();
        this.renderWeeklyScheduleSkeleton(this.getScheduleDayDefinitions(this.getActiveScheduleReferenceDate()));
        this.renderWeeklyMenuSkeleton(this.getMenuDayDefinitions(new Date(), this.maxMenuDayCount));
        await Promise.all([
            this.loadAcademicBriefing(),
            this.initializeSimulator(),
            this.loadWeeklySchedule(),
            this.loadWeeklyMenu()
        ]);
    }

    cacheElements() {
        this.studentNameEl = document.getElementById('student-name');
        this.currentDateEl = document.getElementById('current-date');
        this.lastSyncEl = document.getElementById('last-sync');
        this.briefingSummaryEl = document.getElementById('briefing-summary');
        this.gradeTrendsEl = document.getElementById('grade-trends');
        this.workloadChartEl = document.getElementById('workload-chart');
        this.courseHealthGridEl = document.getElementById('course-health-grid');
        this.weeklyScheduleEl = document.getElementById('weekly-schedule');
        this.scheduleWeekButtonsEl = document.getElementById('schedule-week-buttons');
        this.scheduleWeekRangeEl = document.getElementById('schedule-week-range');
        this.schedulePrevDayEl = document.getElementById('schedule-prev-day');
        this.scheduleNextDayEl = document.getElementById('schedule-next-day');
        this.scheduleCurrentDayLabelEl = document.getElementById('schedule-current-day-label');
        this.weeklyMenuEl = document.getElementById('weekly-menu');
        this.courseSelectorEl = document.getElementById('course-selector');
        this.resetSimulatorEl = document.getElementById('reset-simulator');
        this.trimesterButtonGroupEl = document.getElementById('trimester-button-group');
        this.simulatorOverallGradeEl = document.getElementById('simulator-overall-grade');
        this.remainingWorkSummaryEl = document.getElementById('remaining-work-summary');
        this.simulatorTableBodyEl = document.getElementById('simulator-table-body');
        this.targetButtonGroupEl = document.getElementById('target-button-group');
        this.targetGradeOutputEl = document.getElementById('target-grade-output');
        this.refreshBriefingEl = document.getElementById('refresh-briefing');
        this.openSettingsEl = document.getElementById('open-settings');
    }

    bindEvents() {
        this.courseSelectorEl.addEventListener('change', () => this.handleCourseSelection());
        this.resetSimulatorEl.addEventListener('click', () => this.resetSimulator());
        this.trimesterButtonGroupEl.addEventListener('click', (event) => {
            const button = event.target.closest('[data-trimester]');
            if (!button) return;
            this.handleTrimesterSelection(button.dataset.trimester);
        });
        this.targetButtonGroupEl.addEventListener('click', (event) => {
            const button = event.target.closest('.target-button');
            if (!button) return;
            this.selectedTarget = Number(button.dataset.target);
            [...this.targetButtonGroupEl.querySelectorAll('.target-button')].forEach(item => {
                item.classList.toggle('active', item === button);
            });
            this.updateTargetGradeOutput();
        });
        this.refreshBriefingEl.addEventListener('click', () => this.loadAcademicBriefing(true));
        this.openSettingsEl.addEventListener('click', () => chrome.runtime.openOptionsPage());
        this.schedulePrevDayEl.addEventListener('click', () => this.changeWeeklyScheduleDay(-1));
        this.scheduleNextDayEl.addEventListener('click', () => this.changeWeeklyScheduleDay(1));
        this.scheduleWeekButtonsEl.addEventListener('click', (event) => {
            const button = event.target.closest('[data-week-offset]');
            if (!button) return;
            const weekOffset = Number(button.dataset.weekOffset);
            if (!Number.isInteger(weekOffset)) return;
            void this.selectScheduleWeek(weekOffset);
        });
    }

    async sendMessage(message, retries = 3) {
        for (let attempt = 0; attempt < retries; attempt++) {
            // Wake the service worker
            await new Promise((resolve) => {
                chrome.runtime.sendMessage({ type: 'PING' }, () => {
                    void chrome.runtime.lastError; // suppress error
                    resolve();
                });
            });
    
            // ← KEY FIX: wait for SW to fully wake before sending real message
            await new Promise(r => setTimeout(r, 150));
    
            const response = await new Promise((resolve) => {
                chrome.runtime.sendMessage(message, (res) => {
                    void chrome.runtime.lastError;
                    resolve(res);
                });
            });
    
            if (response !== undefined) {
                if (!response.success) {
                    throw new Error(response.error || 'Request failed');
                }
                return response;
            }
    
            // SW died mid-flight — wait longer before next retry
            console.warn(`sendMessage: attempt ${attempt + 1} got undefined, retrying...`);
            await new Promise(r => setTimeout(r, 300 * (attempt + 1)));
        }
    
        throw new Error('Service worker unavailable after retries');
    }

    async loadCachedData() {
        try {
            const response = await this.sendMessage({ type: 'GET_CACHED_DATA' });
            this.canvasData = response.data || {
                user: null,
                courses: [],
                assignments: [],
                assignmentGrades: [],
                announcements: [],
                calendarEvents: []
            };
            this.lastUpdate = response.lastUpdate || null;
        } catch (error) {
            console.error('Dashboard: Failed to load cached data', error);
            this.canvasData = {
                user: null,
                courses: [],
                assignments: [],
                assignmentGrades: [],
                announcements: [],
                calendarEvents: []
            };
            this.lastUpdate = null;
        }
    }

    renderHeader() {
        this.studentNameEl.textContent = this.canvasData?.user?.name || 'Academic Overview';
        this.currentDateEl.textContent = new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            year: 'numeric'
        });
        this.lastSyncEl.textContent = this.lastUpdate ? this.formatRelativeTime(this.lastUpdate) : 'Not synced';
    }

    async loadAcademicBriefing(forceRefresh = false) {
        if (forceRefresh) {
            this.briefingSummaryEl.textContent = 'Refreshing your academic briefing.';
        }

        try {
            const response = await this.sendMessage({ type: 'GET_ACADEMIC_BRIEFING' });
            this.briefing = response.data;
            this.briefingSummaryEl.textContent = response.data.summary;
        } catch (error) {
            console.error('Dashboard: Failed to load academic briefing', error);
            this.briefingSummaryEl.textContent = 'Academic briefing is unavailable right now. The dashboard visuals below still reflect your latest synced data.';
        }
    }

    /*
     * PRE-WORK FINDINGS
     * Menu source: extension/background.js uses SageDiningMenuService.fetchMenu(mealType, date), exposed to the dashboard through FETCH_DINING_MENU; it returns { success, date, meals: { breakfast|lunch|dinner: [{ name, category, meal }] } }.
     * Schedule source: extension/background.js uses fetchBlackbaudStudentScheduleData(referenceDate, resolvedUserId), exposed through FETCH_BLACKBAUD_STUDENT_SCHEDULE; it returns { entries: [{ date, startTime, endTime, courseName, teacherName, room }], startDate, endDate }.
     * Current week logic: dashboard getScheduleDayDefinitions(referenceDate) and background getBlackbaudStudentScheduleDateRange(referenceDate) both normalize the reference date back to Monday (Sunday maps to the prior Monday) and use a Monday-through-Friday range.
     * Server note: backend/server.js defines the get_dining_menu tool contract and Blackbaud proxy route, but no dedicated dining menu HTTP route; the dashboard reuses the existing extension message flow instead of adding one.
     */

    /**
     * @param {Date} referenceDate
     * @returns {number}
     */
    getInitialScheduleDayIndex(referenceDate) {
        const weekday = new Date(referenceDate).getDay();
        return weekday >= 1 && weekday <= 5 ? weekday - 1 : 0;
    }

    /**
     * @param {Date} referenceDate
     * @param {number} weekOffset
     * @returns {Date}
     */
    getWeekStartDate(referenceDate, weekOffset = 0) {
        const baseDate = new Date(referenceDate);
        baseDate.setHours(0, 0, 0, 0);
        const weekday = baseDate.getDay();
        const offsetFromMonday = weekday === 0 ? 6 : weekday - 1;
        baseDate.setDate(baseDate.getDate() - offsetFromMonday + (weekOffset * 7));
        return baseDate;
    }

    /**
     * @param {Date} referenceDate
     * @returns {Array<{offset:number,label:string,referenceDate:Date,startDate:Date,endDate:Date,buttonRange:string,headingRange:string}>}
     */
    getScheduleWeekDefinitions(referenceDate) {
        const labels = ['This Week', 'Next Week', 'Week 3', 'Week 4'];
        return Array.from({ length: labels.length }, (_, offset) => {
            const startDate = this.getWeekStartDate(referenceDate, offset);
            const endDate = new Date(startDate);
            endDate.setDate(startDate.getDate() + 4);
            return {
                offset,
                label: labels[offset],
                referenceDate: new Date(startDate),
                startDate,
                endDate,
                buttonRange: this.formatWeekRangeText(startDate, endDate, false),
                headingRange: this.formatWeekRangeText(startDate, endDate, true)
            };
        });
    }

    /**
     * @param {number} weekOffset
     * @returns {{offset:number,label:string,referenceDate:Date,startDate:Date,endDate:Date,buttonRange:string,headingRange:string}}
     */
    getScheduleWeekDefinition(weekOffset) {
        return this.scheduleWeekDefinitions[weekOffset] || this.scheduleWeekDefinitions[0];
    }

    /**
     * @returns {Date}
     */
    getActiveScheduleReferenceDate() {
        return this.getScheduleWeekDefinition(this.activeScheduleWeekOffset).referenceDate;
    }

    /**
     * @param {Date} startDate
     * @param {Date} endDate
     * @param {boolean} includeYear
     * @returns {string}
     */
    formatWeekRangeText(startDate, endDate, includeYear) {
        const startMonth = startDate.toLocaleDateString('en-US', { month: 'short' });
        const endMonth = endDate.toLocaleDateString('en-US', { month: 'short' });
        const startDay = startDate.getDate();
        const endDay = endDate.getDate();
        const year = endDate.getFullYear();
        const range = startMonth === endMonth
            ? `${startMonth} ${startDay} – ${endDay}`
            : `${startMonth} ${startDay} – ${endMonth} ${endDay}`;
        return includeYear ? `${range}, ${year}` : range;
    }

    /**
     * @param {Date} referenceDate
     * @returns {Array<{index:number,label:string,fullLabel:string,shortDate:string,isoDate:string,isToday:boolean}>}
     */
    getScheduleDayDefinitions(referenceDate) {
        const baseDate = this.getWeekStartDate(referenceDate);
        return Array.from({ length: 5 }, (_, index) => {
            const dayDate = new Date(baseDate);
            dayDate.setDate(baseDate.getDate() + index);
            const isoDate = this.toIsoDate(dayDate);
            return {
                index,
                label: dayDate.toLocaleDateString('en-US', { weekday: 'short' }),
                fullLabel: dayDate.toLocaleDateString('en-US', { weekday: 'long' }),
                shortDate: dayDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
                isoDate,
                isToday: isoDate === this.toIsoDate(new Date())
            };
        });
    }

    /**
     * @param {Date} referenceDate
     * @param {number} dayCount
     * @returns {Array<{index:number,label:string,shortDate:string,isoDate:string,isToday:boolean}>}
     */
    getMenuDayDefinitions(referenceDate, dayCount) {
        const baseDate = this.getWeekStartDate(referenceDate);
        const todayIsoDate = this.toIsoDate(new Date());
        return Array.from({ length: dayCount }, (_, index) => {
            const dayDate = new Date(baseDate);
            dayDate.setDate(baseDate.getDate() + index);
            const isoDate = this.toIsoDate(dayDate);
            return {
                index,
                label: dayDate.toLocaleDateString('en-US', { weekday: 'short' }),
                shortDate: dayDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
                isoDate,
                isToday: isoDate === todayIsoDate
            };
        });
    }

    /**
     * @param {Date} date
     * @returns {string}
     */
    toIsoDate(date) {
        const normalizedDate = new Date(date);
        normalizedDate.setHours(0, 0, 0, 0);
        return normalizedDate.toISOString().split('T')[0];
    }

    /**
     * @param {number} offset
     * @returns {void}
     */
    changeWeeklyScheduleDay(offset) {
        const days = this.getScheduleDayDefinitions(this.getActiveScheduleReferenceDate());
        const nextIndex = Math.max(0, Math.min(days.length - 1, this.activeScheduleDayIndex + offset));
        if (nextIndex === this.activeScheduleDayIndex) return;
        this.activeScheduleDayIndex = nextIndex;
        if (this.scheduleLoadErrorMessage) {
            this.renderWeeklyScheduleError(this.scheduleLoadErrorMessage, days);
            return;
        }
        this.renderWeeklySchedule(this.weeklyScheduleEntries);
    }

    /**
     * @returns {void}
     */
    renderScheduleWeekButtons() {
        this.scheduleWeekButtonsEl.innerHTML = this.scheduleWeekDefinitions.map(week => `
            <button
                type="button"
                class="secondary-button schedule-week-button ${week.offset === this.activeScheduleWeekOffset ? 'is-active' : ''}"
                data-week-offset="${week.offset}"
                aria-pressed="${week.offset === this.activeScheduleWeekOffset ? 'true' : 'false'}"
            >
                <span class="schedule-week-button__label">${week.label}</span>
                <span class="schedule-week-button__range">${week.buttonRange}</span>
            </button>
        `).join('');
    }

    /**
     * @returns {void}
     */
    renderScheduleWeekRange() {
        const activeWeek = this.getScheduleWeekDefinition(this.activeScheduleWeekOffset);
        this.scheduleWeekRangeEl.textContent = `Week of ${activeWeek.headingRange}`;
    }

    /**
     * @param {number} weekOffset
     * @returns {Promise<void>}
     */
    async selectScheduleWeek(weekOffset) {
        if (!Number.isInteger(weekOffset) || weekOffset < 0 || weekOffset >= this.scheduleWeekDefinitions.length) {
            return;
        }
        if (weekOffset === this.activeScheduleWeekOffset && this.scheduleWeekCache[weekOffset]) {
            return;
        }
        this.activeScheduleDayIndex = weekOffset === 0 ? this.getInitialScheduleDayIndex(new Date()) : 0;
        await this.loadWeeklySchedule(weekOffset);
    }

    /**
     * @param {Array<{index:number,label:string,fullLabel:string,shortDate:string,isoDate:string,isToday:boolean}>} days
     * @returns {void}
     */
    updateWeeklyScheduleNavigation(days) {
        const activeDay = days[this.activeScheduleDayIndex] || days[0] || null;
        this.scheduleCurrentDayLabelEl.textContent = activeDay
            ? `${activeDay.fullLabel} · ${activeDay.shortDate}`
            : 'This week';
        this.schedulePrevDayEl.disabled = this.activeScheduleDayIndex <= 0;
        this.scheduleNextDayEl.disabled = this.activeScheduleDayIndex >= days.length - 1;
    }

    /**
     * @param {Array<{index:number,label:string,fullLabel:string,shortDate:string,isoDate:string,isToday:boolean}>} days
     * @returns {void}
     */
    renderWeeklyScheduleSkeleton(days) {
        this.scheduleLoadErrorMessage = '';
        this.weeklyScheduleEl.innerHTML = `
            <div class="weekly-schedule-grid" aria-busy="true">
                ${days.map(day => `
                    <article class="schedule-day-column ${day.isToday ? 'schedule-day-column--today' : ''} ${day.index === this.activeScheduleDayIndex ? 'is-active' : ''}" data-day-index="${day.index}">
                        <div class="schedule-day-header">
                            <h3>${day.label}</h3>
                            <p class="meta-text">${day.shortDate}</p>
                        </div>
                        <div class="schedule-day-list">
                            ${Array.from({ length: 3 }, () => `
                                <div class="schedule-class-card schedule-class-card--skeleton" aria-hidden="true">
                                    <div class="schedule-skeleton schedule-skeleton--title"></div>
                                    <div class="schedule-skeleton schedule-skeleton--time"></div>
                                    <div class="schedule-skeleton schedule-skeleton--meta"></div>
                                </div>
                            `).join('')}
                        </div>
                    </article>
                `).join('')}
            </div>
        `;
        this.updateWeeklyScheduleNavigation(days);
    }

    /**
     * @param {string} message
     * @param {Array<{index:number,label:string,fullLabel:string,shortDate:string,isoDate:string,isToday:boolean}>} days
     * @returns {void}
     */
    renderWeeklyScheduleError(message, days) {
        this.scheduleLoadErrorMessage = message;
        this.weeklyScheduleEl.innerHTML = `<div class="empty-state schedule-inline-error">${this.escapeHtml(message)}</div>`;
        this.weeklyScheduleEl.setAttribute('aria-busy', 'false');
        this.updateWeeklyScheduleNavigation(days);
    }

    /**
     * @param {number} weekOffset
     * @returns {Promise<void>}
     */
    async loadWeeklySchedule(weekOffset = this.activeScheduleWeekOffset) {
        const activeWeek = this.getScheduleWeekDefinition(weekOffset);
        const days = this.getScheduleDayDefinitions(activeWeek.referenceDate);
        const requestToken = ++this.scheduleRequestToken;
        this.activeScheduleWeekOffset = weekOffset;
        this.renderScheduleWeekButtons();
        this.renderScheduleWeekRange();

        if (this.scheduleWeekCache[weekOffset]) {
            this.scheduleLoadErrorMessage = '';
            this.weeklyScheduleEntries = this.scheduleWeekCache[weekOffset];
            this.renderWeeklySchedule(this.weeklyScheduleEntries);
            return;
        }

        this.renderWeeklyScheduleSkeleton(days);

        try {
            // ── Resolve BB user ID (cached after first fetch) ──────────
            if (!this.blackbaudUserId) {
                try {
                    const meResponse = await this.sendMessage({
                        type: 'BLACKBAUD_PROXY',
                        endpoint: '/school/v1/users/me',
                        method: 'GET'
                    });
                    this.blackbaudUserId = meResponse?.data?.id;
                } catch (idError) {
                    console.warn('Dashboard: Could not resolve BB user ID via proxy, trying schedule directly', idError);
                }
                if (!this.blackbaudUserId) throw new Error('Could not resolve Blackbaud user ID');
            }

            const response = await this.sendMessage({
                type: 'FETCH_BLACKBAUD_STUDENT_SCHEDULE',
                referenceDate: activeWeek.referenceDate.toISOString(),
                userId: this.blackbaudUserId
            });
            if (requestToken !== this.scheduleRequestToken) return;
            this.weeklyScheduleEntries = Array.isArray(response.data?.entries) ? response.data.entries : [];
            this.scheduleWeekCache[weekOffset] = this.weeklyScheduleEntries;
            this.renderWeeklySchedule(this.weeklyScheduleEntries);
        } catch (error) {
            if (requestToken !== this.scheduleRequestToken) return;
            console.error('Dashboard: Failed to load weekly schedule', error);
            this.weeklyScheduleEntries = [];
            this.renderWeeklyScheduleError('Weekly schedule is unavailable right now.', days);
        }
    }

    /**
     * @param {Array<{date:string,startTime:string,endTime:string,courseName:string,teacherName:string,room:string}>} entries
     * @returns {void}
     */
    renderWeeklySchedule(entries) {
        this.scheduleLoadErrorMessage = '';
        const days = this.getScheduleDayDefinitions(this.getActiveScheduleReferenceDate());
        const groupedEntries = this.groupWeeklyScheduleEntries(entries, days);

        this.weeklyScheduleEl.innerHTML = `
            <div class="weekly-schedule-grid" aria-busy="false">
                ${days.map(day => {
                    const dayEntries = groupedEntries.get(day.isoDate) || [];
                    return `
                        <article class="schedule-day-column ${day.isToday ? 'schedule-day-column--today' : ''} ${day.index === this.activeScheduleDayIndex ? 'is-active' : ''}" data-day-index="${day.index}">
                            <div class="schedule-day-header">
                                <h3>${day.label}</h3>
                                <p class="meta-text">${day.shortDate}</p>
                            </div>
                            <div class="schedule-day-list">
                                ${dayEntries.length > 0
                                    ? dayEntries.map(entry => `
                                        <div class="schedule-class-card">
                                            <div class="schedule-class-title">${this.escapeHtml(entry.courseName || 'Class')}</div>
                                            <div class="schedule-class-time">${this.escapeHtml(this.formatWeeklyScheduleTimeRange(entry.startTime, entry.endTime))}</div>
                                            ${this.getWeeklyScheduleMetaLine(entry)
                                                ? `<div class="schedule-class-meta">${this.escapeHtml(this.getWeeklyScheduleMetaLine(entry))}</div>`
                                                : ''}
                                        </div>
                                    `).join('')
                                    : '<div class="schedule-empty-day">No classes</div>'
                                }
                            </div>
                        </article>
                    `;
                }).join('')}
            </div>
        `;

        this.updateWeeklyScheduleNavigation(days);
    }

    /**
     * @param {Array<{date:string,startTime:string,endTime:string,courseName:string,teacherName:string,room:string}>} entries
     * @param {Array<{isoDate:string}>} days
     * @returns {Map<string, Array<{date:string,startTime:string,endTime:string,courseName:string,teacherName:string,room:string}>>}
     */
    groupWeeklyScheduleEntries(entries, days) {
        const groupedEntries = new Map(days.map(day => [day.isoDate, []]));

        entries.forEach(entry => {
            if (!entry?.date || !groupedEntries.has(entry.date)) return;
            groupedEntries.get(entry.date).push(entry);
        });

        groupedEntries.forEach(dayEntries => {
            dayEntries.sort((a, b) => this.getWeeklyScheduleSortValue(a.startTime) - this.getWeeklyScheduleSortValue(b.startTime));
        });

        return groupedEntries;
    }

    /**
     * @param {string} timeValue
     * @returns {number}
     */
    getWeeklyScheduleSortValue(timeValue) {
        if (!timeValue) return Infinity;
        const [hours = '99', minutes = '99'] = String(timeValue).split(':');
        return Number(hours) * 60 + Number(minutes);
    }

    /**
     * @param {string} startTime
     * @param {string} endTime
     * @returns {string}
     */
    formatWeeklyScheduleTimeRange(startTime, endTime) {
        const formattedStart = this.formatWeeklyScheduleTime(startTime);
        const formattedEnd = this.formatWeeklyScheduleTime(endTime);

        if (!formattedStart && !formattedEnd) return 'Time unavailable';
        if (!formattedEnd) return formattedStart;
        if (!formattedStart) return formattedEnd;
        return `${formattedStart} – ${formattedEnd}`;
    }

    /**
     * @param {string} timeValue
     * @returns {string}
     */
    formatWeeklyScheduleTime(timeValue) {
        if (!timeValue) return '';

        const match = String(timeValue).match(/^(\d{1,2}):(\d{2})/);
        if (!match) return String(timeValue);

        const hours = Number(match[1]);
        const minutes = match[2];
        if (!Number.isFinite(hours)) return String(timeValue);

        const normalizedHours = hours % 12 || 12;
        const meridiem = hours >= 12 ? 'PM' : 'AM';
        return `${normalizedHours}:${minutes} ${meridiem}`;
    }

    /**
     * @param {{teacherName?:string,room?:string}} entry
     * @returns {string}
     */
    getWeeklyScheduleMetaLine(entry) {
        return [entry.teacherName, entry.room].filter(Boolean).join(' • ');
    }

    /**
     * @param {Array<{index:number,label:string,shortDate:string,isoDate:string,isToday:boolean}>} days
     * @returns {void}
     */
    renderWeeklyMenuSkeleton(days) {
        this.weeklyMenuEl.innerHTML = `
            <div class="menu-week-grid" style="--menu-grid-columns: ${days.length};" aria-busy="true">
                ${days.map(day => `
                    <article class="schedule-day-column ${day.isToday ? 'schedule-day-column--today' : ''}">
                        <div class="schedule-day-header">
                            <h3>${day.label}</h3>
                            <p class="meta-text">${day.shortDate}</p>
                        </div>
                        <div class="schedule-day-list">
                            ${Array.from({ length: 3 }, () => `
                                <div class="schedule-class-card schedule-class-card--skeleton" aria-hidden="true">
                                    <div class="schedule-skeleton schedule-skeleton--title"></div>
                                    <div class="schedule-skeleton schedule-skeleton--time"></div>
                                    <div class="schedule-skeleton schedule-skeleton--meta"></div>
                                </div>
                            `).join('')}
                        </div>
                    </article>
                `).join('')}
            </div>
        `;
    }

    /**
     * @returns {Promise<void>}
     */
    async loadWeeklyMenu() {
        const requestedDays = this.getMenuDayDefinitions(new Date(), this.maxMenuDayCount);
        this.renderWeeklyMenuSkeleton(requestedDays);

        try {
            const responses = await Promise.all(requestedDays.map(day => this.sendMessage({
                type: 'FETCH_DINING_MENU',
                date: day.isoDate
            })));

            this.menuDisplayDayCount = this.getWeeklyMenuDayCount(responses);
            const visibleResponses = responses.slice(0, this.menuDisplayDayCount);
            this.weeklyMenuByDate = new Map(
                visibleResponses.map((response, index) => [requestedDays[index].isoDate, response?.data || null])
            );
            this.renderWeeklyMenu();
        } catch (error) {
            console.error('Dashboard: Failed to load weekly menu', error);
            this.weeklyMenuEl.innerHTML = '<div class="empty-state schedule-inline-error">Menu unavailable. Try again later.</div>';
            this.weeklyMenuEl.setAttribute('aria-busy', 'false');
        }
    }

    /**
     * @param {Array<{data?:{success?:boolean,meals?:Record<string, Array<{name:string,category:string,meal:string}>>}}>} responses
     * @returns {number}
     */
    getWeeklyMenuDayCount(responses) {
        const hasWeekendData = responses.slice(5).some(response => this.hasMenuData(response?.data));
        return hasWeekendData ? 7 : 5;
    }

    /**
     * @param {{success?:boolean,meals?:Record<string, Array<{name:string,category:string,meal:string}>>}|null|undefined} menuData
     * @returns {boolean}
     */
    hasMenuData(menuData) {
        if (!menuData?.success || !menuData.meals) return false;
        return ['breakfast', 'lunch', 'dinner'].some(mealName => Array.isArray(menuData.meals[mealName]) && menuData.meals[mealName].length > 0);
    }

    /**
     * @param {{success?:boolean,meals?:Record<string, Array<{name:string,category:string,meal:string}>>}|null|undefined} menuData
     * @param {'breakfast'|'lunch'|'dinner'} mealName
     * @returns {string[]}
     */
    getMenuEntrees(menuData, mealName) {
        const entreePattern = /(entree|entrée|entrees|entrées|main|grill|rotisserie)/i;
        const mealEntries = Array.isArray(menuData?.meals?.[mealName]) ? menuData.meals[mealName] : [];
        return mealEntries
            .filter(item => entreePattern.test(String(item?.category || '')))
            .map(item => String(item?.name || '').trim())
            .filter(Boolean);
    }

    /**
     * @returns {void}
     */
    renderWeeklyMenu() {
        const days = this.getMenuDayDefinitions(new Date(), this.menuDisplayDayCount);
        const mealLabels = [
            ['breakfast', 'Breakfast'],
            ['lunch', 'Lunch'],
            ['dinner', 'Dinner']
        ];

        this.weeklyMenuEl.innerHTML = `
            <div class="menu-week-grid" style="--menu-grid-columns: ${days.length};" aria-busy="false">
                ${days.map(day => {
                    const menuData = this.weeklyMenuByDate.get(day.isoDate) || null;
                    return `
                        <article class="schedule-day-column menu-day-column ${day.isToday ? 'schedule-day-column--today' : ''}">
                            <div class="schedule-day-header">
                                <h3>${day.label}</h3>
                                <p class="meta-text">${day.shortDate}</p>
                            </div>
                            ${this.hasMenuData(menuData)
                                ? `<div class="menu-day-list">
                                    ${mealLabels.map(([mealKey, label]) => {
                                        const items = this.getMenuEntrees(menuData, mealKey);
                                        return `
                                            <section class="menu-meal-block">
                                                <p class="menu-meal-label">${label}</p>
                                                ${items.length > 0
                                                    ? `<ul class="menu-meal-items">${items.map(item => `<li>${this.escapeHtml(item)}</li>`).join('')}</ul>`
                                                    : '<p class="menu-placeholder">—</p>'
                                                }
                                            </section>
                                        `;
                                    }).join('')}
                                </div>`
                                : '<div class="schedule-empty-day menu-empty-day">No menu available</div>'
                            }
                        </article>
                    `;
                }).join('')}
            </div>
        `;
    }

    renderGradeTrends() {
        const courses = this.canvasData?.courses || [];
        if (courses.length === 0) {
            this.gradeTrendsEl.innerHTML = '<div class="empty-state">No course grade history is available yet.</div>';
            return;
        }

        const cards = courses.map(course => {
            const courseGrades = this.getChartGradeEntries(course.id).slice(-6);

            const values = courseGrades.map(grade => Number(grade.percentage));
            const chart = values.length >= 2 ? this.buildSparkline(values) : '<div class="empty-state">Need at least two graded items to show a trend.</div>';
            const trendDelta = values.length >= 2 ? values[values.length - 1] - values[0] : 0;
            const trendClass = trendDelta > 1 ? 'trend-up' : trendDelta < -1 ? 'trend-down' : 'trend-flat';
            const trendLabel = trendDelta > 1 ? `▲ ${Math.abs(trendDelta).toFixed(0)} pts` : trendDelta < -1 ? `▼ ${Math.abs(trendDelta).toFixed(0)} pts` : 'Flat';

            return `
                <article class="trend-card">
                    <div class="health-top">
                        <div>
                            <h3>${this.escapeHtml(course.name)}</h3>
                            <p class="meta-text">Last ${values.length || 0} graded items</p>
                        </div>
                        <strong class="${trendClass}">${trendLabel}</strong>
                    </div>
                    ${chart}
                </article>
            `;
        });

        this.gradeTrendsEl.innerHTML = cards.join('');
    }

    renderWeeklyWorkloadChart() {
        const assignments = (this.canvasData?.assignments || []).filter(assignment => assignment.dueDate);
        const { buckets: dayBuckets, columnCount } = this.buildWeeklyWorkloadBuckets(assignments);
        if (DASHBOARD_DEBUG) {
            console.log('Dashboard workload buckets', dayBuckets);
        }

        const maxTotal = Math.max(...dayBuckets.map(bucket => bucket.total), 0);
        this.workloadChartEl.style.setProperty('--workload-columns', columnCount);
        this.workloadChartEl.innerHTML = dayBuckets.map(bucket => {
            const height = maxTotal > 0 ? (bucket.total / maxTotal) * 100 : 0;
            const dayLabel = bucket.date.toLocaleDateString('en-US', { weekday: 'short' });
            const dateLabel = bucket.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            const assignmentCountLabel = `${bucket.count} assignment${bucket.count === 1 ? '' : 's'}`;
            const assignmentPreview = bucket.assignments.length > 0
                ? `
                    <div class="workload-assignment-list">
                        ${bucket.assignments.slice(0, WORKLOAD_VISIBLE_ASSIGNMENTS).map(assignment => `
                            <span class="workload-assignment-chip">${this.escapeHtml(this.truncateText(assignment.title, WORKLOAD_ASSIGNMENT_TITLE_MAX_LENGTH))}</span>
                        `).join('')}
                        ${bucket.assignments.length > WORKLOAD_VISIBLE_ASSIGNMENTS
                            ? `<span class="workload-assignment-more">+${bucket.assignments.length - WORKLOAD_VISIBLE_ASSIGNMENTS} more</span>`
                            : ''}
                    </div>
                `
                : '<span class="workload-assignment-empty">No assignments</span>';
            const bucketClasses = [
                'workload-day',
                bucket.isToday ? 'workload-day--today' : '',
                bucket.isPast ? 'workload-day--past' : ''
            ].filter(Boolean).join(' ');
            const barClasses = [
                'workload-bar',
                bucket.urgencyClass,
                bucket.isToday ? 'workload-bar--today' : ''
            ].filter(Boolean).join(' ');
            const hoverPanel = bucket.assignments.length > 0 ? `
                <div class="workload-hover-panel" role="dialog" aria-label="Assignments for ${this.escapeHtml(`${bucket.label}, ${dateLabel}`)}" hidden>
                    <div class="hover-panel-header">${this.escapeHtml(`${bucket.label}, ${dateLabel}`)}</div>
                    <ul class="hover-assignment-list">
                        ${bucket.assignments.map(assignment => `
                            <li class="hover-assignment-item">
                                <div class="hover-assignment-info">
                                    <span class="hover-assignment-title">${this.escapeHtml(this.truncateText(assignment.title, 40))}</span>
                                    <span class="hover-assignment-course">${this.escapeHtml(assignment.courseName || 'Unknown Course')}</span>
                                </div>
                                <div class="hover-assignment-actions">
                                    <button class="hover-open-btn" aria-label="Open ${this.escapeHtml(assignment.title)}" data-url="${this.escapeHtml(assignment.url || '')}">↗</button>
                                    <button class="hover-ai-btn" aria-label="Ask AI about ${this.escapeHtml(assignment.title)}" data-title="${this.escapeHtml(assignment.title)}" data-course="${this.escapeHtml(assignment.courseName || '')}" data-url="${this.escapeHtml(assignment.url || '')}">AI</button>
                                </div>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            ` : '';
            return `
                <div class="${bucketClasses}"
                    data-date="${bucket.isoDate}"
                    tabindex="0"
                    role="button"
                    aria-expanded="false"
                    aria-label="${this.escapeHtml(`${dayLabel}, ${dateLabel}`)} — ${assignmentCountLabel}">
                    <div class="workload-bar-wrap">
                        <div class="${barClasses}" style="height:${height}%"></div>
                    </div>
                    <strong class="workload-date-heading">${this.escapeHtml(dateLabel)}</strong>
                    <span class="workload-day-label">${this.escapeHtml(dayLabel)}</span>
                    ${assignmentPreview}
                    <span class="chart-caption">${assignmentCountLabel}</span>
                    ${hoverPanel}
                </div>
            `;
        }).join('');

        if (!this.workloadChartEventsBound) {
            this.bindWorkloadChartEvents();
            this.workloadChartEventsBound = true;
        }
    }

    buildWeeklyWorkloadBuckets(assignments) {
        const startOfWeek = this.getStartOfCurrentWeek();
        const today = this.normalizeDateOnly(new Date());
        const bucketCount = WORKLOAD_BUCKET_DAYS;
        const buckets = Array.from({ length: bucketCount }, (_, index) => {
            const dayDate = new Date(startOfWeek);
            dayDate.setDate(startOfWeek.getDate() + index);
            const isoDate = [
                dayDate.getFullYear(),
                String(dayDate.getMonth() + 1).padStart(2, '0'),
                String(dayDate.getDate()).padStart(2, '0')
            ].join('-');
            return {
                label: dayDate.toLocaleDateString('en-US', { weekday: 'short' }),
                isoDate,
                date: dayDate,
                total: 0,
                count: 0,
                assignments: [],
                isToday: dayDate.getTime() === today.getTime(),
                isPast: dayDate.getTime() < today.getTime(),
                urgencyClass: ''
            };
        });

        const bucketMap = new Map(buckets.map(bucket => [bucket.date.getTime(), bucket]));
        assignments.forEach(assignment => {
            const assignmentDay = this.normalizeDateOnly(new Date(assignment.dueDate));
            const bucket = bucketMap.get(assignmentDay.getTime());
            if (!bucket) return;
            bucket.count += 1;
            bucket.total += this.computePriorityScore(assignment);
            bucket.assignments.push({
                title: assignment.title || 'Untitled assignment',
                courseName: assignment.courseName || '',
                url: assignment.url || null,
                points: assignment.points || null,
                dueDate: assignment.dueDate,
                daysUntilDue: Math.ceil((assignmentDay - today) / 86400000)
            });
        });

        buckets.forEach(bucket => {
            bucket.assignments.sort((left, right) => left.title.localeCompare(right.title));
            bucket.urgencyClass = bucket.assignments.length === 0
                ? 'workload-bar--empty'
                : bucket.assignments.some(assignment => assignment.daysUntilDue <= 2)
                    ? 'workload-bar--urgent'
                    : bucket.assignments.some(assignment => assignment.daysUntilDue <= 7)
                        ? 'workload-bar--near'
                        : 'workload-bar--future';
        });

        return { buckets, columnCount: WORKLOAD_BUCKET_COLUMNS };
    }

    getStartOfCurrentWeek() {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const day = today.getDay();
        const offsetFromMonday = day === 0 ? 6 : day - 1;
        today.setDate(today.getDate() - offsetFromMonday);
        return today;
    }

    normalizeDateOnly(value) {
        const normalized = new Date(value);
        if (Number.isNaN(normalized.getTime())) {
            return new Date('Invalid Date');
        }
        normalized.setHours(0, 0, 0, 0);
        return normalized;
    }

    getTrimesterInfo(date) {
        return globalThis.TrimesterUtils?.getTrimesterForDate(date)
            || this.gradeAnalyzerTool?.getTrimesterForDate?.(date)
            || null;
    }

    filterItemsBySelectedTrimester(items, getDate) {
        if (globalThis.TrimesterUtils) {
            // Use the authoritative TrimesterUtils filter. An empty array is a valid
            // result (no items in that trimester) — don't collapse it with || which
            // would trigger the all-items fallback and mix every trimester together.
            const filtered = globalThis.TrimesterUtils.filterByTrimester(items, this.selectedTrimester, {
                currentDate: new Date(),
                getDate
            });
            if (Array.isArray(filtered)) return filtered;
        }
        // TrimesterUtils unavailable: return all items unfiltered. Callers that need an
        // authoritative grade should consume course.grade directly rather than recalculating
        // from these entries (see renderCourseHealthGrid / renderSimulator).
        return [...(items || [])];
    }

    updateActiveTrimesterButtons() {
        if (!this.trimesterButtonGroupEl) return;
        [...this.trimesterButtonGroupEl.querySelectorAll('[data-trimester]')].forEach(button => {
            button.classList.toggle('active', button.dataset.trimester === this.selectedTrimester);
        });
    }

    handleTrimesterSelection(trimesterCode) {
        const resolvedTrimester = globalThis.TrimesterUtils?.resolveTrimesterCode(trimesterCode) || trimesterCode;
        if (!resolvedTrimester || resolvedTrimester === this.selectedTrimester) return;
        this.selectedTrimester = resolvedTrimester;
        this.updateActiveTrimesterButtons();
        this.renderGradeTrends();
        this.renderCourseHealthGrid();
        this.resetSimulator();
    }

    getSimulatorRowsForSelectedTrimester(meta = this.simulatorMeta) {
        if (!meta?.rows) return [];
        return this.filterItemsBySelectedTrimester(meta.rows, (row, currentDate) => row?.dueDate || currentDate)
            .map(row => ({ ...row }));
    }

    getGradeableRows(rows) {
        return rows.filter(row => Number(row.possible) > 0);
    }

    getTrimesterGradeDisplayText(grade) {
        if (grade === 'unavailable') {
            return 'Grade unavailable for this trimester';
        }
        return this.formatGradePercent(grade);
    }

    formatGradePercent(grade) {
        const numericGrade = Number(grade);
        if (!Number.isFinite(numericGrade)) {
            return '--';
        }
        return `${numericGrade.toFixed(2).replace(/\.?0+$/, '')}%`;
    }

    calculateGradeFromEntries(entries) {
        const rows = entries
            .filter(entry => !entry.excused && Number(entry.pointsPossible) > 0)
            .map(entry => ({
                earned: entry.score,
                possible: entry.pointsPossible
            }));

        if (rows.length === 0) return null;

        const gradedRows = rows.filter(row => Number.isFinite(Number(row.earned)));
        if (gradedRows.length === 0) return 'unavailable';

        const earned = gradedRows.reduce((sum, row) => sum + Number(row.earned), 0);
        const possible = gradedRows.reduce((sum, row) => sum + Number(row.possible), 0);
        return possible > 0 ? (earned / possible) * 100 : null;
    }

    getScoredEntries(entries) {
        return entries
            .filter(grade => grade.score !== null && !grade.excused && Number.isFinite(grade.percentage))
            .sort((firstGrade, secondGrade) => this.getGradeSortTimestamp(firstGrade) - this.getGradeSortTimestamp(secondGrade));
    }

    renderCourseHealthGrid() {
        const courses = this.canvasData?.courses || [];
        const assignments = this.filterItemsBySelectedTrimester(
            this.canvasData?.assignments || [],
            (assignment, currentDate) => assignment?.dueDate || currentDate
        );
        if (courses.length === 0) {
            this.courseHealthGridEl.innerHTML = '<div class="empty-state">No courses are available yet.</div>';
            return;
        }

        this.courseHealthGridEl.innerHTML = courses.map(course => {
            const nearestAssignment = assignments
                .filter(assignment => String(assignment.courseId) === String(course.id) && assignment.dueDate && new Date(assignment.dueDate) >= new Date())
                .sort((firstAssignment, secondAssignment) => new Date(firstAssignment.dueDate) - new Date(secondAssignment.dueDate))[0];
            const trimesterEntries = this.getTrimesterGradeEntries(course.id);
            const courseGrades = this.getScoredEntries(trimesterEntries);
            const canonicalCourseGrade = Number.isFinite(Number(course.grade)) ? Number(course.grade) : null;
            // When TrimesterUtils is unavailable, currentTrimesterInfo is null and
            // both optional-chain lookups return undefined. Fall back to DEFAULT_TRIMESTER_CODE
            // so the comparison doesn't silently evaluate to false.
            const currentCode = this.currentTrimesterInfo?.code
                ?? this.currentTrimesterInfo?.trimester
                ?? DEFAULT_TRIMESTER_CODE;
            const isCurrentTrimester = this.selectedTrimester === currentCode || this.selectedTrimester == null;
            const trimesterGrade = (isCurrentTrimester && canonicalCourseGrade != null)
                ? canonicalCourseGrade
                : this.calculateGradeFromEntries(trimesterEntries);
            const gradeIsApproximate = !isCurrentTrimester || canonicalCourseGrade == null;
            const latestValues = courseGrades.slice(-2).map(grade => Number(grade.percentage));
            const trendDelta = latestValues.length === 2 ? latestValues[1] - latestValues[0] : 0;
            const trendClass = trendDelta > 1 ? 'trend-up' : trendDelta < -1 ? 'trend-down' : 'trend-flat';
            const trendArrow = trendDelta > 1 ? '▲' : trendDelta < -1 ? '▼' : '■';
            const deadlineText = nearestAssignment
                ? `${nearestAssignment.title} · ${this.formatShortDate(nearestAssignment.dueDate)}`
                : 'No upcoming deadlines';

            return `
                <article class="health-card">
                    <div class="health-top">
                        <div>
                            <h3>${this.escapeHtml(course.name)}</h3>
                            <p class="meta-text">Nearest deadline</p>
                        </div>
                        <span class="${trendClass}">${trendArrow}</span>
                    </div>
                    <div class="health-grade">${this.escapeHtml(this.getTrimesterGradeDisplayText(trimesterGrade))}${gradeIsApproximate ? '<span class="grade-approx-note" title="Historical trimester — weighting not applied">~</span>' : ''}</div>
                    <p class="meta-text ${trendClass}">${trendDelta === 0 ? 'Stable trend' : `${trendDelta > 0 ? 'Up' : 'Down'} ${Math.abs(trendDelta).toFixed(0)} pts`}</p>
                    <p class="meta-text" style="margin-top: 10px;">${this.escapeHtml(deadlineText)}</p>
                </article>
            `;
        }).join('');
    }

    populateCourseSelector() {
        const courses = this.canvasData?.courses || [];
        if (courses.length === 0) {
            this.courseSelectorEl.innerHTML = '<option value="">No courses available</option>';
            this.courseSelectorEl.disabled = true;
            return;
        }

        this.courseSelectorEl.disabled = false;
        this.courseSelectorEl.innerHTML = courses
            .map(course => `<option value="${this.escapeHtml(course.id)}">${this.escapeHtml(course.name)}</option>`)
            .join('');
    }

    async initializeSimulator() {
        if (!this.courseSelectorEl.value) {
            this.renderSimulatorPlaceholder('Sync your Canvas data to start using the simulator.');
            return;
        }
        await this.handleCourseSelection();
    }

    async handleCourseSelection() {
        const courseId = this.courseSelectorEl.value;
        if (!courseId) {
            this.renderSimulatorPlaceholder('Choose a course to load the grade simulator.');
            return;
        }

        if (!this.simulatorCache.has(courseId)) {
            try {
                const response = await this.sendMessage({ type: 'GET_COURSE_SIMULATOR_DATA', courseId });
                this.simulatorCache.set(courseId, response.data);
            } catch (error) {
                console.error('Dashboard: Failed to load simulator data', error);
                this.renderSimulatorPlaceholder('The grade simulator could not load this course right now.');
                return;
            }
        }

        const cached = this.simulatorCache.get(courseId);
        this.simulatorMeta = cached;
        this.simulatorRows = this.getSimulatorRowsForSelectedTrimester(cached);
        this.renderSimulator();
    }

    resetSimulator() {
        if (!this.simulatorMeta) return;
        this.simulatorRows = this.getSimulatorRowsForSelectedTrimester(this.simulatorMeta);
        this.renderSimulator();
    }

    renderSimulator() {
        if (!this.simulatorMeta) {
            this.renderSimulatorPlaceholder('No assignment data is available for this course.');
            return;
        }

        const gradeableRows = this.getGradeableRows(this.simulatorRows);
        if (gradeableRows.length === 0) {
            this.renderSimulatorPlaceholder(NO_GRADEABLE_TRIMESTER_MESSAGE, NO_GRADEABLE_TRIMESTER_MESSAGE);
            return;
        }

        const hasUserEdits = this.simulatorRows.some(row =>
            row.earned !== row.actualEarned && row.actualEarned !== undefined
        );
        const canvasGrade = Number.isFinite(Number(this.simulatorMeta?.course?.grade))
            ? Number(this.simulatorMeta.course.grade)
            : null;
        const overallGrade = (!hasUserEdits && canvasGrade != null)
            ? canvasGrade
            : this.calculateOverallGrade(this.simulatorRows);
        const isSimulated = hasUserEdits || canvasGrade == null;
        const remainingPoints = gradeableRows
            .filter(row => row.isPending)
            .reduce((sum, row) => sum + Number(row.possible || 0), 0);

        const overallGradeDisplay = this.getTrimesterGradeDisplayText(
            Number.isFinite(overallGrade) ? overallGrade : 'unavailable'
        );
        this.simulatorOverallGradeEl.textContent = overallGradeDisplay;
        if (isSimulated) {
            const simulatedBadge = document.createElement('span');
            simulatedBadge.className = 'simulated-badge';
            simulatedBadge.textContent = 'Simulated';
            this.simulatorOverallGradeEl.append(' ', simulatedBadge);
        }
        this.remainingWorkSummaryEl.textContent = `${Math.round(remainingPoints)} pts across ${gradeableRows.filter(row => row.isPending).length} assignments`;

        this.simulatorTableBodyEl.innerHTML = gradeableRows.map(row => {
            const contribution = this.calculateContribution(row, gradeableRows);
            const isEdited = !row.isPending && row.actualEarned != null && Number(row.earned) !== Number(row.actualEarned);
            const gradePercent = Number.isFinite(Number(row.earned)) && Number(row.possible) > 0
                ? `${((Number(row.earned) / Number(row.possible)) * 100).toFixed(1)}%`
                : '<span class="pending-badge">Pending</span>';
            const contributionText = contribution == null ? '—' : `${contribution.toFixed(1)}%`;
            const weightText = Number(row.categoryWeight) > 0 ? `${Number(row.categoryWeight).toFixed(0)}%` : 'Points';

            return `
                <tr class="grade-row ${row.isPending ? 'pending' : ''} ${isEdited ? 'edited' : ''}" data-assignment-id="${row.assignmentId}">
                    <td>
                        <div class="activity-title">${this.escapeHtml(row.title)}</div>
                        <div class="meta-text">${row.dueDate ? this.formatShortDate(row.dueDate) : 'No due date'}</div>
                    </td>
                    <td>${this.escapeHtml(row.category)}</td>
                    <td>
                        ${row.isPending
                            ? '<span class="pending-badge">Pending</span>'
                            : `<input class="earned-input" type="number" min="0" step="0.1" value="${Number(row.earned).toFixed(1).replace(/\.0$/, '')}" data-assignment-id="${row.assignmentId}">`
                        }
                    </td>
                    <td>${Number(row.possible || 0).toFixed(1).replace(/\.0$/, '')}</td>
                    <td><span class="weight-chip">${weightText}</span></td>
                    <td>${gradePercent}</td>
                    <td>${contributionText}</td>
                </tr>
            `;
        }).join('');

        this.simulatorTableBodyEl.querySelectorAll('.earned-input').forEach(input => {
            input.addEventListener('input', () => {
                const row = this.simulatorRows.find(item => item.assignmentId === input.dataset.assignmentId);
                if (!row) return;
                const value = Number(input.value);
                row.earned = Number.isFinite(value) ? Math.max(0, Math.min(value, Number(row.possible || value))) : row.actualEarned;
                this.renderSimulator();
            });
        });

        this.updateTargetGradeOutput();
    }

    renderSimulatorPlaceholder(message, overallText = '--') {
        this.simulatorOverallGradeEl.textContent = overallText;
        this.remainingWorkSummaryEl.textContent = '--';
        this.simulatorTableBodyEl.innerHTML = `<tr><td colspan="7"><div class="empty-state">${this.escapeHtml(message)}</div></td></tr>`;
        this.targetGradeOutputEl.textContent = 'Select a target grade to calculate what you need on remaining work.';
    }

    updateTargetGradeOutput() {
        if (!this.selectedTarget) {
            this.targetGradeOutputEl.textContent = 'Select a target grade to calculate what you need on remaining work.';
            return;
        }

        const result = this.calculateTargetRequirement(this.simulatorRows, this.selectedTarget);
        if (result.status === 'achieved') {
            this.targetGradeOutputEl.textContent = 'You have already reached this target. Maintain your current average to keep it.';
            return;
        }

        if (result.status === 'impossible') {
            this.targetGradeOutputEl.textContent = 'This target cannot be reached based on available remaining assignments.';
            return;
        }

        this.targetGradeOutputEl.textContent = `To reach ${result.label}, you need an average of ${result.requiredAverage.toFixed(1)}% on remaining work (${Math.round(result.remainingPoints)} pts total).`;
    }

    calculateTargetRequirement(rows, targetPercent) {
        // Mirror renderSimulator: when the user hasn't touched any score yet, use Canvas's
        // authoritative course grade rather than recalculating from potentially mixed-trimester rows.
        const hasUserEdits = rows.some(row =>
            row.earned !== row.actualEarned && row.actualEarned !== undefined
        );
        const canvasGrade = Number.isFinite(Number(this.simulatorMeta?.course?.grade))
            ? Number(this.simulatorMeta.course.grade)
            : null;
        const currentOverall = (!hasUserEdits && canvasGrade != null)
            ? canvasGrade
            : this.calculateOverallGrade(rows);
        const remainingRows = rows.filter(row => row.isPending && Number(row.possible) > 0);
        const remainingPoints = remainingRows.reduce((sum, row) => sum + Number(row.possible), 0);

        const labelMap = {
            93: 'A (93%)',
            90: 'A- (90%)',
            87: 'B+ (87%)',
            83: 'B (83%)',
            80: 'B- (80%)',
            77: 'C+ (77%)',
            73: 'C (73%)'
        };

        if (Number.isFinite(currentOverall) && currentOverall >= targetPercent) {
            return { status: 'achieved', label: labelMap[targetPercent], remainingPoints };
        }

        if (remainingPoints <= 0) {
            return { status: 'impossible', label: labelMap[targetPercent], remainingPoints };
        }

        const maxRows = rows.map(row => row.isPending ? { ...row, earned: Number(row.possible) } : row);
        if (this.calculateOverallGrade(maxRows) < targetPercent) {
            return { status: 'impossible', label: labelMap[targetPercent], remainingPoints };
        }

        let low = 0;
        let high = 100;
        for (let iteration = 0; iteration < MAX_BINARY_SEARCH_ITERATIONS; iteration += 1) {
            const mid = (low + high) / 2;
            const projectedRows = rows.map(row => row.isPending
                ? { ...row, earned: Number(row.possible) * (mid / 100) }
                : row
            );
            const projectedOverall = this.calculateOverallGrade(projectedRows);
            if (projectedOverall >= targetPercent) {
                high = mid;
            } else {
                low = mid;
            }
        }

        return {
            status: 'needed',
            label: labelMap[targetPercent],
            requiredAverage: high,
            remainingPoints
        };
    }

    calculateOverallGrade(rows) {
        const gradedRows = rows.filter(row => Number.isFinite(Number(row.earned)) && Number(row.possible) > 0);
        if (gradedRows.length === 0) return null;

        const hasWeights = this.simulatorMeta?.weightingMode === 'weighted' && gradedRows.some(row => Number(row.categoryWeight) > 0);
        if (!hasWeights) {
            const earned = gradedRows.reduce((sum, row) => sum + Number(row.earned), 0);
            const possible = gradedRows.reduce((sum, row) => sum + Number(row.possible), 0);
            return possible > 0 ? (earned / possible) * 100 : null;
        }

        const groupMap = new Map();
        gradedRows.forEach(row => {
            const key = row.categoryId || row.category;
            const existing = groupMap.get(key) || {
                weight: Number(row.categoryWeight) || 0,
                earned: 0,
                possible: 0
            };
            existing.earned += Number(row.earned);
            existing.possible += Number(row.possible);
            groupMap.set(key, existing);
        });

        let weightedSum = 0;
        let totalWeight = 0;
        groupMap.forEach(group => {
            if (group.possible <= 0 || group.weight <= 0) return;
            weightedSum += (group.earned / group.possible) * 100 * group.weight;
            totalWeight += group.weight;
        });

        if (totalWeight <= 0) {
            const earned = gradedRows.reduce((sum, row) => sum + Number(row.earned), 0);
            const possible = gradedRows.reduce((sum, row) => sum + Number(row.possible), 0);
            return possible > 0 ? (earned / possible) * 100 : null;
        }

        return weightedSum / totalWeight;
    }

    calculateContribution(row, rows) {
        if (row.isPending || !Number.isFinite(Number(row.earned)) || Number(row.possible) <= 0) {
            return null;
        }

        const hasWeights = this.simulatorMeta?.weightingMode === 'weighted' && rows.some(item => Number(item.categoryWeight) > 0);
        if (!hasWeights) {
            const totalPossible = rows
                .filter(item => !item.isPending && Number(item.possible) > 0)
                .reduce((sum, item) => sum + Number(item.possible), 0);
            return totalPossible > 0 ? (Number(row.earned) / totalPossible) * 100 : null;
        }

        const activeGroups = new Map();
        rows.filter(item => !item.isPending && Number(item.possible) > 0).forEach(item => {
            const key = item.categoryId || item.category;
            const current = activeGroups.get(key) || { weight: Number(item.categoryWeight) || 0, possible: 0 };
            current.possible += Number(item.possible);
            activeGroups.set(key, current);
        });

        const totalWeight = [...activeGroups.values()].reduce((sum, item) => sum + (item.weight > 0 ? item.weight : 0), 0);
        const group = activeGroups.get(row.categoryId || row.category);
        if (!group || group.possible <= 0 || totalWeight <= 0 || Number(row.categoryWeight) <= 0) {
            return null;
        }

        return (Number(row.earned) / group.possible) * (Number(row.categoryWeight) / totalWeight) * 100;
    }

    computePriorityScore(assignment) {
        const dueDate = assignment?.dueDate ? new Date(assignment.dueDate) : null;
        const daysUntilDue = dueDate ? Math.ceil((dueDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24)) : 99;
        const points = Number(assignment?.points || 0);
        let score = 8;
        if (daysUntilDue <= 0) score += 20;
        else if (daysUntilDue === 1) score += 16;
        else if (daysUntilDue <= 3) score += 12;
        else if (daysUntilDue <= 7) score += 8;
        if (points >= 100) score += 10;
        else if (points >= 50) score += 6;
        else if (points >= 20) score += 3;
        return score;
    }

    buildSparkline(values) {
        const width = 220;
        const height = 72;
        const min = Math.min(...values);
        const max = Math.max(...values);
        const range = max - min || 1;
        const stepX = values.length === 1 ? width : width / (values.length - 1);
        const points = values.map((value, index) => {
            const x = index * stepX;
            const y = height - (((value - min) / range) * (height - SPARKLINE_VERTICAL_PADDING) + SPARKLINE_OFFSET);
            return { x, y };
        });
        const line = points.map(point => `${point.x},${point.y}`).join(' ');
        const fill = `M ${points[0].x} ${height} L ${line.replace(/,/g, ' ')} L ${points[points.length - 1].x} ${height} Z`;
        const circles = points.map(point => `<circle cx="${point.x}" cy="${point.y}" r="3"></circle>`).join('');
        return `
            <svg class="sparkline" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-hidden="true">
                <path class="fill" d="${fill}"></path>
                <path class="line" d="M ${points.map(point => `${point.x} ${point.y}`).join(' L ')}"></path>
                ${circles}
            </svg>
        `;
    }

    formatShortDate(value) {
        return new Date(value).toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric'
        });
    }

    truncateText(value, maxLength) {
        const text = String(value ?? '');
        if (text.length <= maxLength) {
            return text;
        }
        return `${text.slice(0, Math.max(0, maxLength - 1))}…`;
    }

    bindWorkloadChartEvents() {
        this.workloadChartEl.addEventListener('mouseenter', event => {
            const day = event.target.closest('.workload-day');
            if (!day) return;
            this.setWorkloadPanelState(day, true);
        }, true);

        this.workloadChartEl.addEventListener('mouseleave', event => {
            const day = event.target.closest('.workload-day');
            if (!day || day.contains(event.relatedTarget)) return;
            this.setWorkloadPanelState(day, false);
        }, true);

        this.workloadChartEl.addEventListener('keydown', event => {
            const day = event.target.closest('.workload-day');
            if (!day) return;
            if ((event.key === 'Enter' || event.key === ' ') && event.target === day) {
                event.preventDefault();
                const panel = day.querySelector('.workload-hover-panel');
                if (!panel) return;
                const isOpen = !panel.hidden;
                this.setWorkloadPanelState(day, !isOpen);
            }
            if (event.key === 'Escape') {
                this.workloadChartEl.querySelectorAll('.workload-hover-panel').forEach(panel => {
                    panel.hidden = true;
                });
                day.setAttribute('aria-expanded', 'false');
                day.focus();
            }
        });

        this.workloadChartEl.addEventListener('click', event => {
            const openBtn = event.target.closest('.hover-open-btn');
            if (openBtn?.dataset.url) {
                this.openAssignmentUrl(openBtn.dataset.url);
                return;
            }

            const aiBtn = event.target.closest('.hover-ai-btn');
            if (aiBtn) {
                this.askAIAboutAssignment(aiBtn.dataset.title, aiBtn.dataset.course, aiBtn.dataset.url);
            }
        });
    }

    setWorkloadPanelState(day, isOpen) {
        const panel = day?.querySelector('.workload-hover-panel');
        if (!panel) {
            day?.setAttribute('aria-expanded', 'false');
            return;
        }
        panel.hidden = !isOpen;
        day.setAttribute('aria-expanded', String(isOpen));
    }

    openAssignmentUrl(url) {
        if (!url) return;
        chrome.tabs.create({ url });
    }

    askAIAboutAssignment(title, courseName, assignmentUrl) {
        const query = `Help me with "${title}" in ${courseName}. Walk me through the key concepts, what I need to know to complete it, and any tips.`;
        chrome.runtime.sendMessage({
            type: 'OPEN_CHATBOT_WITH_QUERY',
            query,
            assignmentUrl
        });
    }

    getTrimesterGradeEntries(courseId) {
        const grades = Array.isArray(this.canvasData?.assignmentGrades) ? this.canvasData.assignmentGrades : [];
        return this.filterItemsBySelectedTrimester(
            grades.filter(grade => String(grade.courseId) === String(courseId)),
            (grade, currentDate) => grade?.dueAt ?? currentDate
        ).map(grade => this.normalizeGradeEntry(grade));
    }

    getChartGradeEntries(courseId) {
        return this.getScoredEntries(this.getTrimesterGradeEntries(courseId));
    }

    normalizeGradeEntry(grade) {
        const score = grade?.score != null ? Number(grade.score) : null;
        const pointsPossible = Number(grade?.pointsPossible);
        const fallbackPercentage = score != null && Number.isFinite(pointsPossible) && pointsPossible > 0
            ? (score / pointsPossible) * 100
            : null;

        return {
            ...grade,
            score,
            pointsPossible,
            percentage: Number.isFinite(Number(grade?.percentage))
                ? Number(grade.percentage)
                : fallbackPercentage,
            chartDate: this.gradeAnalyzerTool?.getGradeDate
                ? this.gradeAnalyzerTool.getGradeDate(grade)
                : this.getFallbackGradeDate(grade)
        };
    }

    getFallbackGradeDate(grade) {
        if (!this.hasLoggedGradeAnalyzerFallback) {
            console.warn('Dashboard: GradeAnalyzerTool unavailable, using local grade date fallback.');
            this.hasLoggedGradeAnalyzerFallback = true;
        }
        return grade?.dueAt || grade?.gradedAt || grade?.submittedAt || null;
    }

    getGradeSortTimestamp(grade) {
        const timestamp = grade?.chartDate || grade?.gradedAt || grade?.dueAt;
        if (!timestamp) return Number.MAX_SAFE_INTEGER;
        const parsed = new Date(timestamp).getTime();
        return Number.isNaN(parsed) ? Number.MAX_SAFE_INTEGER : parsed;
    }

    formatRelativeTime(value) {
        const diffMinutes = Math.round((Date.now() - new Date(value).getTime()) / 60000);
        if (diffMinutes < 1) return 'just now';
        if (diffMinutes < 60) return `${diffMinutes}m ago`;
        if (diffMinutes < 1440) return `${Math.round(diffMinutes / 60)}h ago`;
        return `${Math.round(diffMinutes / 1440)}d ago`;
    }

    escapeHtml(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new AcademicDashboard();
});
